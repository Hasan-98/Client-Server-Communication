/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.kalsym.demo;

/**
 *
 * @author hasan
 */

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.boot.autoconfigure.web.ErrorProperties;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.RequestMapping;



@RestController
public class GreetingController {
    int i = 1;
    @GetMapping("/greetings")
    public String greeting(@RequestParam(name="" , required=false , defaultValue="User") String name , Greeting greet){
        greet.setContent(name);
        i++;
        return "Hello, "+  greet.getContent()+"! ";
    }
}



